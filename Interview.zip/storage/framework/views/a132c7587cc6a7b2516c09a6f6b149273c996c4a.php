<html>
<head>
  <title>view blog</title>

<meta name="url" content="<?php echo e(url('view-blog')); ?>/<?php echo e($view->id); ?>">
<link rel="canonical" href="<?php echo e(url('view-blog')); ?>/<?php echo e($view->id); ?>">

<meta property="og:title" content="<?php echo e($view->title); ?>" />
<meta property="og:description" content="<?php echo e(Str::limit(150,$view->description)); ?>" />

<meta property="og:image" content="<?php echo e(asset($view->img)); ?>" />

<meta property="og:site_name" content="Interview" />
<meta property="og:url" content="<?php echo e(url('view-blog')); ?>/<?php echo e($view->id); ?>" />
<meta property="og:type" content="website" />
<meta property="og:locale" content="en_US" />
</head>

<body style="text-align:center ">
  <h1><?php echo e($view->title); ?></h1><br>
  <img width="80%" src="<?php echo e(asset($view->img)); ?>">
  <p><?php echo e($view->description); ?></p>
</body>

</html><?php /**PATH C:\xampp\htdocs\htdocs\laravel\inteview_project\Interview\resources\views/view_blog.blade.php ENDPATH**/ ?>