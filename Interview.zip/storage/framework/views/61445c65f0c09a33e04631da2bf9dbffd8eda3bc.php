<link rel="stylesheet" href="<?php echo e(asset('style_from.css')); ?>">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

<form method="post" action="submit-blog" enctype="multipart/form-data">
  <h1>Insert Blog</h1>
  <?php echo csrf_field(); ?>
 
  
  <div class="row">
    
    <input type="text" name="title" id="title" required/>
    <label for="title">Title</label>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
  <div class="row">
    <input type="file" name="img" id="img" required />

    <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
  <div class="row">
    <textarea name="description" id="description" required></textarea>
    <label for="description">Description</label>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="row">
    <input type="radio" name="fancy-radio" id="fancy-radio-1"/>
    <label for="fancy-radio-1">Radio</label>
    
    <input type="radio" name="fancy-radio" id="fancy-radio-2"/>
    <label for="fancy-radio-2">Radio</label>
  </div>
  
  <button type="submit" tabindex="0">Submit</button>
</form>

<?php /**PATH C:\xampp\htdocs\htdocs\laravel\inteview_project\Interview\resources\views/insert_blog.blade.php ENDPATH**/ ?>